Torque2D
========

MIT Licensed Open Source version of Torque 2D from GarageGames.

You can find the main Wiki page [here](https://github.com/GarageGames/Torque2D/wiki)
