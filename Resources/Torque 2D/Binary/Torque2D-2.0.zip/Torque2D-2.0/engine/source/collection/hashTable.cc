//-----------------------------------------------------------------------------
// Copyright (c) 2013 GarageGames, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//-----------------------------------------------------------------------------

#include "hashTable.h"


namespace Hash
{

//-Mat all this was copied from StringTable
	bool sgInitTable = true;
	U8   sgtHashTable[256];

	void initTolowerTable()
	{
	   for (U32 i = 0; i < 256; i++) {
		  U8 c = dTolower(i);
		  sgtHashTable[i] = c * c;
	   }

	   sgInitTable = false;
	}


   U32 hash(const char *str)
   {
	   if (sgInitTable)
		  initTolowerTable();

	   U32 ret = 0;
	   char c;
	   while((c = *str++) != 0) {
		  ret <<= 1;
		  ret ^= sgtHashTable[c];
	   }
	   return ret;
   }
//-Mat

	static U32 Primes[] = {
	  53ul,         97ul,         193ul,       389ul,       769ul,
	  1543ul,       3079ul,       6151ul,      12289ul,     24593ul,
	  49157ul,      98317ul,      196613ul,    393241ul,    786433ul,
	  1572869ul,    3145739ul,    6291469ul,   12582917ul,  25165843ul,
	  50331653ul,   100663319ul,  201326611ul, 402653189ul, 805306457ul,
	  1610612741ul, 3221225473ul, 4294967291ul
	};

	U32 nextPrime(U32 size)
	{
	   U32 len = sizeof(Primes) / sizeof(U32);
	   for(U32 i=0; i<len; i++)
		  if(Primes[i] > size)
			 return Primes[i];

	   return Primes[len-1];
	}

};

