
AL_FUNCTION(ALenum, EAXSet, (const ALGUID*, ALuint, ALuint, ALvoid*, ALuint), return 0; )
AL_FUNCTION(ALenum, EAXGet, (const ALGUID*, ALuint, ALuint, ALvoid*, ALuint), return 0; )
